
/***show hide nav bar */

$(document).ready(function(){

	'use-strict';
	$(window).scroll(function(){

		'use-strict';
		if($(window).scrollTop() < 80) {
			$('.navbar').css({
				'margin-top': '-100px',
				'opacity': '0'
			});

			$('.navbar-default').css({
				'background-color':'rgba(59, 59, 59, 0)'
			});

		} else {
			$('.navbar').css({
				'margin-top': '0px',
				'opacity': '1'
			});

			$('.navbar-default').css({
				'background-color':'rgba(59, 59, 59, 0.7)',
				'border-color':'#444'
			});
			$('.navbar-brand img').css({
				'height': '40px'
			});
		}
		
	});
});


// active menu item on click 

$(document).ready(function(){

	$('.navbar-nav li a').click(function(){
		$('.navbar-nav li a').parent().removeClass('active');
		$(this).parent().addClass('active');
});

});
//highlight menu item for scroll 

// $(document).ready(function(){

// 	$(window).scroll(function(){
// 		$('section').each(function(){
// 			var sectionId = $(this).attr('id');
// 			var hei = $(this).outerHeight();
// 			var  grptop = $(this).offset().top - 50;
// 			if($(window).scrollTop()> grptop && $(window).scrollTop() < grptop + hei){
// 				$('.navbar-nav li a[href='#" + bb + "']").parent().addClass('active');



// 			}
// 			else {
// 				$('.navbar-nav li a[href='#" + bb + "']").parent().removeClass('active');
// 			}
// 		});
// 	});
// });

//add auto padding to header 

// $(document).ready(function(){
// 	setInterval( function(){

// 		var windowHeight = $(window).height();
// 		var containerheight = $('.header-conatiner').height();
// 		var padTop = windowHeight - containerheight;

// 		$(".header-conatiner").css({
// 			'padding-top' : Math.round(padTop /2 )+'px',
// 			'padding-bottom' : Math.round(padTop /2 )+'px'

// 		}, 10);
// 	});
// });

//Add Bx Slider
$(document).ready(function(){
  $('.bxslider').bxSlider({

  	slideWidth : 292.5,
  	auto : true,
  	minSlides :1,
  	maxSlides : 3,
  	slideMargin: 50

  });
});

// $(document).ready(function(){
// 	$('.counter-num').counterUp({
//     delay: 10,
//     time: 2000
// });
// });

$(document).ready(function(){
	'use-strict';
	new WOW().init();
});
